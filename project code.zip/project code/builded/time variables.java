 import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Date;

public class reg2 extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{

Date dte = new Date();
String d=dte.toString();
char[] dt={d.charAt(8),d.charAt(9)};
char[] h={d.charAt(11),d.charAt(12)};
char[] mn={d.charAt(14),d.charAt(15)};
String date=new String(dt);
String hour=new String(h);
String min=new String(mn);
res.setContentType("text/html");
PrintWriter out=res.getWriter();
out.println("<html><head><title>register</title></head>");
out.println("<body bgcolor=\"skyblue\"><p style=\"text-align:center\">date : "+date+"</br>date :"+date+ "</br>hour val : "+hour+"</br>min val : "+min+"</br><a href=\"http://localhost:8086/irshad/login.html\">Go to home page</a></p></br><p style=\"text-align:center;color:red;font-size:30px\">Account has been created successfully");
out.println("</p></body></html>");
}
}