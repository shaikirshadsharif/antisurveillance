//program to place time element(hour) in particular place

import java.io.*;
import java.util.Date;
public class irshad
{
public static void main(String args[])
{
int i,p1=2,p2=5;
String bpwd=new String("hello");
char[] bpwdc=bpwd.toCharArray();
Date d=new Date();
String s=new String();
s=d.toString();
char[] h={s.charAt(11),s.charAt(12)};
String hr=new String(h);
char[] m={s.charAt(14),s.charAt(15)};
String min=new String(m);
String tpwd=new String("");
for(i=0;i<bpwd.length();i++)
{
if(i==(p1-1))
tpwd=tpwd+hr;
if(i==(p2-1))
tpwd=tpwd+min;
tpwd=tpwd+bpwdc[i];
}
System.out.println(d+" new password is : "+tpwd);
}
} 