import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class cr extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
{
res.setContentType("text/html");
PrintWriter out=res.getWriter();
Cookie[] cks=req.getCookies();
Cookie ck1=cks[0];
Cookie ck2=cks[1];
Cookie ck3=cks[2];
Cookie ck4=cks[3];
out.println("<html><head><title>cookie</title></head><body bgcolor=\"red\">cookie retrieved \n position:"+ck1.getName()+"\n function :"+ck1.getValue()+"\n position:"+ck2.getName()+"\n function :"+ck2.getValue()+"\n position:"+ck3.getName()+"\n function :"+ck3.getValue()+"\n position:"+ck4.getName()+"\n function :"+ck4.getValue()+"</body></html>");
}
}
