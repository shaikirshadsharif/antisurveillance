import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Date;

public class reg5 extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{

Date date = new Date();
String d=date.toString();
String mp=req.getParameter("mpos");
String mf=req.getParameter("mfun");
String dp=req.getParameter("dpos");
String df=req.getParameter("dfun");
String hp=req.getParameter("hpos");
String hf=req.getParameter("hfun");
String minp=req.getParameter("minpos");
String minf=req.getParameter("minfun");
char[] h={d.charAt(11),d.charAt(12)};
String hr=new String(h);
Cookie ck1=new Cookie(mpos,mfun);
res.addCookie(ck);
Cookie ck2=new Cookie(dpos,dfun);
res.addCookie(ck2);
Cookie ck3=new Cookie(hpos,hfun);
res.addCookie(ck3);
Cookie ck4=new Cookie(minpos,minfun);
res.addCookie(ck4);

res.setContentType("text/html");
PrintWriter out=res.getWriter();
out.println("<html><head><title>register</title></head>");
out.println("<body bgcolor=\"skyblue\"><p style=\"text-align:center\"><p>mpos : "+mp+" mfun : "+mf+" dpos : "+dp+" dfun :"+df+" hpos :"+hp+" hfun :"+hf+" minpos :"+minp+" minfun :"+minf+"<a href=\"http://localhost:8086/irshad/login.html\">Go to home page</a></p></br><p style=\"text-align:center;color:red;font-size:30px\">Account has been created successfully");
out.println("</p></body></html>");
}
}