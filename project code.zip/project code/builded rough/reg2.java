 import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Date;

public class reg extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{

Date date = new Date();
String d=date.toString();
char[] h={d.charAt(11),d.charAt(12)};
String hr=new String(h);
res.setContentType("text/html");
PrintWriter out=res.getWriter();
out.println("<html><head><title>register</title></head>");
out.println("<body bgcolor=\"skyblue\"><p style=\"text-align:center\">date : "+date+"<a href=\"http://localhost:8086/irshad/login.html\">Go to home page</a></p></br><p style=\"text-align:center;color:red;font-size:30px\">Account has been created successfully");
out.println("</p></body></html>");
}
}